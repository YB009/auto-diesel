export default [
    {
      title: 'Plant Hire Companies',
      desc: 'Service and support for plant hire fleets and heavy equipment.'
    },
    {
      title: 'Fork Lift Companies',
      desc: 'Diagnostics and repair for electric and diesel forklift systems.'
    },
    {
      title: 'Local Authorities',
      desc: 'Trusted support partner for council and municipal vehicle electrics.'
    },
    {
      title: 'General Trade & Public',
      desc: 'From classic cars to commercial vans — we help keep you moving.'
    }
  ];