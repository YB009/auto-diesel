export default [
    {
      name: 'tuga2112',
      quote:
        "I've used this company a few times and each time great service received. Today I needed a rush job and the lads sorted the issue out promptly. Wouldn't hesitate to recommend."
    },
    {
      name: 'Michael Moody',
      quote:
        'Good place to get your starter or alternator to. They can fix stuff that other places will tell you to replace for a lot more than it takes to fix. Knowledgeable people with buckets of experience. Certainly will be using their services in future.'
    },
    {
      name: 'Ian Hulse',
      quote: 'Always happy to help with great knowledge.'
    },
    {
      name: 'Charlie Parsons',
      quote:
        'Had several repairs recently to starter and alternator for 38 year old Triumph TR7. Done almost immediately and at a very, very fair price. Nice guys and excellent service. Will recommend to like minded enthusiasts.'
    },
    {
      name: 'John Doe',
      quote:
        'First class service from Steve and his team, very knowledgeable and fantastic advice on our alternator repair — highly recommend.'
    }
  ];